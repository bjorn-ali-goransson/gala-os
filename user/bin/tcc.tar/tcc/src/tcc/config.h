#define TCC_VERSION "0.9.28rc"
#define TCC_GITHASH "mob:e23dabe"
